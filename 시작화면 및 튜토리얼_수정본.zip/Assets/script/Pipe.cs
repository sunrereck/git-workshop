﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pipe : MonoBehaviour {
    public const float speed = 5.2f;
    private Sprite thisSprite;
    Vector3 vector;
    // Use this for initialization
    void Start()
    {
        thisSprite = GetComponent<SpriteRenderer>().sprite;
      
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
        if (transform.position.x < -17f)
        {
            Destroy(gameObject);
        }
    }
}
