﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class emoticon : MonoBehaviour
{
    float acttime = 0;
    // Use this for initialization
    void Update()

    {

        acttime += Time.deltaTime;


        {
            if (acttime > 5)
            {
                GetComponent<Animator>().Play("emoticon");
            }

            else
            {

                GetComponent<Animator>().Play("blue");
            }
        }


    }
}