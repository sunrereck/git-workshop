﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballmove : MonoBehaviour {


     

    public float moveSpeed;
    public float yForce;
    public float xForce;
    public float dampenForce;
    
   
    Rigidbody2D rigid;
    private Vector3 mPos1;
    private Vector3 mPos2;
    
    void Start () {//시작할때 
        rigid = gameObject.GetComponent<Rigidbody2D>();
        //스크립트가 붙은 오브젝트의 Rigidbody2D 컴포넌트를 얻어온다.
        //안붙이면 못불러오는경우가 많았음
        
	}
	
	
	void Update () {//계속 fps마다 
        
       // MoveControl();
        
        if(Input.GetMouseButtonDown(0))//마우스를 눌렀을때
        {
            Debug.Log("Mouse Left Clicked!!!");
            mPos1 = Input.mousePosition;
        }

        if(Input.mousePosition != mPos1 && Input.GetMouseButton(0))
        {

        }
        if (Input.GetMouseButtonUp(0))//마우스를 뗐을때
        {
            mPos2 = Input.mousePosition;

            xForce += (mPos1.x - mPos2.x)/50;
            yForce += (mPos1.y - mPos2.y)/50;
            rigid.gravityScale = 1;
            rigid.velocity = new Vector2(xForce, yForce);
            //rigid.AddForce(new Vector2(xForce, yForce));

            xForce = 0f;
            yForce = 0f;
        }

    }

    void MoveControl()//밖으로 못나가게 하는함수
    {
        float moveX = moveSpeed * Time.deltaTime * Input.GetAxis("Horizontal");
        
        float moveY = moveSpeed * Time.deltaTime * Input.GetAxis("Horizontal");
        transform.Translate(moveX,moveY, 0);

        Vector3 viewPos = Camera.main.WorldToViewportPoint(transform.position);
        viewPos.x = Mathf.Clamp01(viewPos.x);
        viewPos.y = Mathf.Clamp01(viewPos.y);

        print(viewPos);

        Vector3 worldPos = Camera.main.ViewportToWorldPoint(viewPos);
        transform.position = worldPos;
    }
}
