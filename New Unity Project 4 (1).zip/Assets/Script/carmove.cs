﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class carmove : MonoBehaviour {

    GameObject ball;
    public float inix;
    float drt = -1;
	// Use this for initialization
	void Start () {
        this.ball = GameObject.Find("Ball");
        inix = transform.position.x;

	}
	
	// Update is called once per frame
	void Update () {
        print(Mathf.Abs((inix) - (transform.position.x)));

        changedrt();

        transform.Translate(drt * 0.01f, 0, 0);

        //

        
    }

    void changedrt()
    {
        if (Mathf.Abs((inix) - (transform.position.x)) > 1.34)
        {
            drt = 1;
            Flip();
        }
        else if (Mathf.Abs((inix) - (transform.position.x)) < 0.1)
        {
            drt = -1;
            Flip();
        }      
    }

    void Flip()
    {
        Vector3 theScale = transform.localScale;
        theScale.x = -drt*2.1f;
        transform.localScale = theScale;
    }
}
