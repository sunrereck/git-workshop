﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loop : MonoBehaviour {

    public const float speed = 5.2f;
    private Sprite thisSprite;
    private float m_minX;
    Vector3 vector;
	// Use this for initialization
	void Start () {
        thisSprite = GetComponent<SpriteRenderer>().sprite;
        m_minX = -1 * thisSprite.bounds.size.x;
	}
	
	// Update is called once per frame
	void Update () {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
        if (transform.position.x < -17f)
        {
            vector = transform.position;
            vector.x = 17f;
            transform.position = vector;
        }
    }
}
