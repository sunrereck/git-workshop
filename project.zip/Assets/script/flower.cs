﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class flower : MonoBehaviour
{
    float acttime = 0;
    // Use this for initialization
    void Update()

    {

        acttime += Time.deltaTime;


        {
            if (acttime > 9)
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.up * 0f);
            }
           else if(acttime > 8)
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.up * 13f);
            }
            else if (acttime > 7)
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.up * 13f);
            }
            else if (acttime > 6)
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.up * 13f);
            }
            else
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.up * 0f);
            }
        }


    }
}