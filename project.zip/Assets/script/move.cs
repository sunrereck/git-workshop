﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour {

	
	void Update () {
       
        {
            GetComponent<Animator>().Play("hero");
        }
        
    }
}
