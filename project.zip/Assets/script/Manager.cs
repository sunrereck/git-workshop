﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour {
    public GameObject car;
    public GameObject truck;
    public GameObject black;
    public Transform carSpawn;
    public Transform truckSpawn;
    public Transform blackSpawn;

    // Use this for initialization
    void Start () {
        InvokeRepeating("spawnpipe", 1, 10);
        InvokeRepeating("spawnpipe2",5, 10);
        InvokeRepeating("spawnpipe3", 4, 7);
    }
	
	// Update is called once per frame
	void Update () {
        
	}

    void spawnpipe()
    {
        Instantiate(car, carSpawn.position, Quaternion.identity);
        
    }
    void spawnpipe2()
    {
        Instantiate(truck, truckSpawn.position, Quaternion.identity);
    }
    void spawnpipe3()
    {
        Instantiate(black, blackSpawn.position, Quaternion.identity);
    }
}
