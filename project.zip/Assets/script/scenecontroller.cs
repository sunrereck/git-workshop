﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class scenecontroller : MonoBehaviour {

	// Use this for initialization
	public void ChangeScene_int(int num) {
        SceneManager.LoadScene(num);
    }
		
	
	
	// Update is called once per frame
    public void ChangeScene_string(string str)
    {
        SceneManager.LoadScene(str);
    }
}
