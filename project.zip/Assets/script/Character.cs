﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    float acttime = 0;
    // Use this for initialization
    void Update()

    {

        acttime += Time.deltaTime;


        {
            if (acttime > 4)
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.right * 0f);
            }

            else
            {
                GetComponent<Rigidbody2D>().AddForce(Vector3.right * 19f);

            }
        }


    }
}