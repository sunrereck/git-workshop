﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class gamecontroller : MonoBehaviour {
    public GameObject BoxPrefab, BoxMakePosition;
    public Text scoreText;
    int score = 0;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        score++;
        if(score % 100 == 0)
        {
            Instantiate(BoxPrefab, BoxMakePosition.transform.position, Quaternion.identity);
        }
        scoreText.text = (score / 10) + " M ";
    }
   
}
